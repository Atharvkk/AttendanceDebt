import SwiftUI

@main
struct AttendanceDebtApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
